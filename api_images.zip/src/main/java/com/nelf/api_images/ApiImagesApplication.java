package com.nelf.api_images;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiImagesApplication {

    public static void main(String[] args) {
        SpringApplication.run(ApiImagesApplication.class, args);
    }

}
