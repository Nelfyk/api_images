package com.nelf.api_images;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiImagesApplicationTests {

    @Test
    void contextLoads() {
    }

}
